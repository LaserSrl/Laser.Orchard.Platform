142 mini country flags (16x16px)
================================

Designer: Yummygum (https://www.iconfinder.com/yummygum)
License: Free for commercial use
